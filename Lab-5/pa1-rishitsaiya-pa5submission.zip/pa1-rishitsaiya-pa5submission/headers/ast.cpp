/*
    Acknowledgement(s): (Akshat Karani)
*/

#include "ast.hpp"
#include <string>

std::string ASTNode::id_type;

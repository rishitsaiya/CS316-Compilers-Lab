#!/bin/sh
rm -f $2
touch $2
./a.out $1 > $2